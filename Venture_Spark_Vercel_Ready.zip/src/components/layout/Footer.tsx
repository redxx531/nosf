import Link from 'next/link';

export default function Footer() {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-light py-4 mt-auto">
      <div className="container">
        <div className="row">
          <div className="col-lg-4 mb-3 mb-lg-0">
            <h5 className="text-primary">Launch Tribe</h5>
            <p className="text-muted">Connecting entrepreneurs with investors of all levels.</p>
          </div>
          
          <div className="col-lg-4 mb-3 mb-lg-0">
            <h6>Quick Links</h6>
            <ul className="list-unstyled">
              <li><Link href="/" className="text-decoration-none">Home</Link></li>
              <li><Link href="/projects" className="text-decoration-none">Explore Projects</Link></li>
              <li><Link href="/signup" className="text-decoration-none">Join Now</Link></li>
            </ul>
          </div>
          
          <div className="col-lg-4">
            <h6>Connect With Us</h6>
            <div className="d-flex gap-3 fs-5">
              <a href="#" className="text-decoration-none" aria-label="Twitter">
                <i className="bi bi-twitter"></i>
              </a>
              <a href="#" className="text-decoration-none" aria-label="Facebook">
                <i className="bi bi-facebook"></i>
              </a>
              <a href="#" className="text-decoration-none" aria-label="Instagram">
                <i className="bi bi-instagram"></i>
              </a>
              <a href="#" className="text-decoration-none" aria-label="LinkedIn">
                <i className="bi bi-linkedin"></i>
              </a>
            </div>
          </div>
        </div>
        
        <hr className="my-4" />
        
        <div className="row align-items-center">
          <div className="col-md-6 text-center text-md-start">
            <p className="mb-0">&copy; {currentYear} Launch Tribe. All rights reserved.</p>
          </div>
          <div className="col-md-6 text-center text-md-end mt-3 mt-md-0">
            <ul className="list-inline mb-0">
              <li className="list-inline-item">
                <Link href="/privacy" className="text-decoration-none small">Privacy Policy</Link>
              </li>
              <li className="list-inline-item">
                <Link href="/terms" className="text-decoration-none small">Terms of Service</Link>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </footer>
  );
}