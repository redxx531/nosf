import Link from 'next/link';
import { useSession, signOut } from 'next-auth/react';
import { useRouter } from 'next/router';
import { useState } from 'react';
import { UserType } from '@/types';

export default function Header() {
  const { data: session } = useSession();
  const router = useRouter();
  const [isNavOpen, setIsNavOpen] = useState(false);

  const toggleNav = () => setIsNavOpen(!isNavOpen);
  
  const getDashboardLink = () => {
    if (!session) return '/login';
    
    switch (session.user.userType) {
      case UserType.ENTREPRENEUR:
        return '/dashboard/entrepreneur';
      case UserType.INVESTOR:
        return '/dashboard/investor';
      case UserType.ADMIN:
        return '/dashboard/admin';
      default:
        return '/';
    }
  };

  return (
    <header className="navbar navbar-expand-lg navbar-dark bg-primary">
      <div className="container">
        <Link href="/" className="navbar-brand d-flex align-items-center">
          <i className="bi bi-rocket-takeoff me-2"></i>
          <span>Launch Tribe</span>
        </Link>
        
        <button
          className="navbar-toggler"
          type="button"
          onClick={toggleNav}
          aria-controls="navbarNav"
          aria-expanded={isNavOpen}
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>
        
        <div className={`collapse navbar-collapse ${isNavOpen ? 'show' : ''}`} id="navbarNav">
          <ul className="navbar-nav me-auto">
            <li className="nav-item">
              <Link 
                href="/projects" 
                className={`nav-link ${router.pathname === '/projects' ? 'active' : ''}`}
              >
                Explore Projects
              </Link>
            </li>
            
            {session?.user.userType === UserType.ENTREPRENEUR && (
              <li className="nav-item">
                <Link 
                  href="/dashboard/entrepreneur/new-project" 
                  className={`nav-link ${router.pathname === '/dashboard/entrepreneur/new-project' ? 'active' : ''}`}
                >
                  Submit Project
                </Link>
              </li>
            )}
          </ul>
          
          <ul className="navbar-nav">
            {session ? (
              <>
                <li className="nav-item">
                  <Link 
                    href={getDashboardLink()} 
                    className={`nav-link ${router.pathname.startsWith('/dashboard') ? 'active' : ''}`}
                  >
                    Dashboard
                  </Link>
                </li>
                <li className="nav-item dropdown">
                  <a 
                    className="nav-link dropdown-toggle" 
                    href="#" 
                    id="userDropdown" 
                    role="button" 
                    data-bs-toggle="dropdown" 
                    aria-expanded="false"
                  >
                    {session.user.name || session.user.email}
                  </a>
                  <ul className="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                    <li>
                      <span className="dropdown-item-text text-muted small">
                        {session.user.userType.charAt(0).toUpperCase() + session.user.userType.slice(1)}
                      </span>
                    </li>
                    <li><hr className="dropdown-divider" /></li>
                    <li>
                      <button 
                        className="dropdown-item" 
                        onClick={() => signOut({ callbackUrl: '/' })}
                      >
                        Logout
                      </button>
                    </li>
                  </ul>
                </li>
              </>
            ) : (
              <>
                <li className="nav-item">
                  <Link 
                    href="/login" 
                    className={`nav-link ${router.pathname === '/login' ? 'active' : ''}`}
                  >
                    Login
                  </Link>
                </li>
                <li className="nav-item">
                  <Link 
                    href="/signup" 
                    className={`nav-link ${router.pathname === '/signup' ? 'active' : ''}`}
                  >
                    Sign Up
                  </Link>
                </li>
              </>
            )}
          </ul>
        </div>
      </div>
    </header>
  );
}