import Link from 'next/link';
import { useSession } from 'next-auth/react';
import { UserType } from '@/types';

export default function Hero() {
  const { data: session } = useSession();
  
  const getStartedLink = () => {
    if (!session) return '/signup';
    
    switch (session.user.userType) {
      case UserType.ENTREPRENEUR:
        return '/dashboard/entrepreneur/new-project';
      case UserType.INVESTOR:
        return '/projects';
      case UserType.ADMIN:
        return '/dashboard/admin';
      default:
        return '/signup';
    }
  };
  
  const getStartedText = () => {
    if (!session) return 'Get Started';
    
    switch (session.user.userType) {
      case UserType.ENTREPRENEUR:
        return 'Submit Your Project';
      case UserType.INVESTOR:
        return 'Discover Projects';
      case UserType.ADMIN:
        return 'Go to Dashboard';
      default:
        return 'Get Started';
    }
  };

  return (
    <section className="py-5 text-center bg-gradient text-white position-relative" 
      style={{
        backgroundImage: 'linear-gradient(135deg, #4b6cb7 0%, #182848 100%)',
        padding: '100px 0'
      }}
    >
      <div className="position-absolute top-0 end-0 bottom-0 start-0 opacity-10" 
        style={{
          backgroundImage: 'url("data:image/svg+xml,%3Csvg width="60" height="60" viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg"%3E%3Cg fill="none" fill-rule="evenodd"%3E%3Cg fill="%239C92AC" fill-opacity="0.22"%3E%3Cpath d="M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z"/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")',
        }}
      ></div>
      
      <div className="container position-relative">
        <div className="row justify-content-center">
          <div className="col-lg-8">
            <h1 className="display-4 fw-bold mb-4">Turn Ideas Into Reality</h1>
            <p className="lead mb-5">
              Launch Tribe connects entrepreneurs with investors of all levels. 
              Whether you're looking to fund your next big idea or discover promising ventures,
              you're in the right place.
            </p>
            <div className="d-flex justify-content-center gap-3">
              <Link href={getStartedLink()} className="btn btn-primary btn-lg px-4">
                {getStartedText()}
              </Link>
              <Link href="/projects" className="btn btn-outline-light btn-lg px-4">
                Explore Projects
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}