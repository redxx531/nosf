import { useSession } from 'next-auth/react';
import Layout from '@/components/layout/Layout';
import Hero from '@/components/home/Hero';
import FeaturedProjects from '@/components/home/FeaturedProjects';
import HowItWorks from '@/components/home/HowItWorks';
import Stats from '@/components/home/Stats';
import Testimonials from '@/components/home/Testimonials';

export default function Home() {
  const { data: session } = useSession();
  
  return (
    <Layout title="Launch Tribe - Connect Entrepreneurs with Investors">
      <Hero />
      
      <FeaturedProjects />
      
      <Stats />
      
      <HowItWorks />
      
      <Testimonials />
      
      <section className="py-5 bg-primary text-white text-center">
        <div className="container">
          <div className="row justify-content-center">
            <div className="col-lg-8">
              <h2 className="mb-4">Ready to Get Started?</h2>
              <p className="lead mb-4">
                Whether you're an entrepreneur with a great idea or an investor looking for opportunities,
                Launch Tribe is the platform for you.
              </p>
              <a href="/signup" className="btn btn-light btn-lg px-4">
                Join Launch Tribe Today
              </a>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}